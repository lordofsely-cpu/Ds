package com.sely.launcher.performance

import android.content.Context

/**
 * Sely Performance System (spec section 44).
 *
 * Stated plainly, per the spec's own requirement: "Never falsely claim
 * the launcher can directly overclock or unlock CPU/GPU performance."
 * A launcher has no API to touch CPU/GPU clocking, thermal policy, or
 * scheduler priority (🔴, kernel/OEM territory) — nothing here pretends
 * otherwise. What a launcher genuinely controls is its OWN behavior:
 *
 *  🟢 BATTERY — disables Sely's own screen-transition animations
 *     (AppDrawer/Sidebar slide/fade — real, just toggled off), and adds
 *     a real `Constraints.setRequiresCharging(true)` to the wallpaper
 *     rotation WorkManager job so it only runs while charging.
 *  🟢 PERFORMANCE — keeps Sely's animations on (they're cheap either
 *     way; this mode is mostly a statement of intent + the honest
 *     framing below).
 *  🟢 BALANCED — the default: animations on, no extra rotation
 *     constraint.
 *
 * For real OS-level power savings, this screen deep-links to Android's
 * own Battery Saver settings (same pattern as Control Center's Wi-Fi
 * tile) rather than duplicating a toggle Sely has no authority over.
 */
enum class PerformanceMode(val label: String, val description: String) {
    BATTERY("Battery", "Sely's own animations off; wallpaper rotation only while charging"),
    BALANCED("Balanced", "Normal Sely experience"),
    PERFORMANCE("Performance", "Sely's animations on, maximum responsiveness within what a launcher controls")
}

object PerformanceModeStore {
    private const val PREFS = "sely_performance"
    private const val KEY_MODE = "mode"

    fun getMode(context: Context): PerformanceMode {
        val name = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_MODE, PerformanceMode.BALANCED.name)
        return PerformanceMode.values().firstOrNull { it.name == name } ?: PerformanceMode.BALANCED
    }

    fun setMode(context: Context, mode: PerformanceMode) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_MODE, mode.name).apply()
    }

    fun animationsEnabled(context: Context) = getMode(context) != PerformanceMode.BATTERY
    fun requireChargingForBackgroundWork(context: Context) = getMode(context) == PerformanceMode.BATTERY
}
