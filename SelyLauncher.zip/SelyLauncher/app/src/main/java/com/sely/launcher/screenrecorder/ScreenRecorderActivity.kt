package com.sely.launcher.screenrecorder

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.sely.launcher.databinding.ActivityScreenRecorderBinding
import com.sely.launcher.theme.ThemeManager

/**
 * Sely Screen Recorder (spec section 20) — control screen.
 *
 * "Start Recording" launches `createScreenCaptureIntent()`, which shows
 * Android's own system dialog naming Sely and warning what will be
 * captured — this can't be skipped or pre-approved (see
 * ScreenRecordService's class doc). Once the user approves it here,
 * the result is handed to the foreground service that does the actual
 * capture.
 *
 * "Show touch indicators" (spec's option) is 🔴 and deliberately absent:
 * enabling system-wide "show taps" requires `WRITE_SECURE_SETTINGS`, a
 * signature-level permission no regular app — launcher or otherwise —
 * can hold. Recording audio is offered as microphone-only for now (see
 * the service for why device/internal audio capture is a separate,
 * larger increment).
 */
class ScreenRecorderActivity : AppCompatActivity() {

    private lateinit var binding: ActivityScreenRecorderBinding
    private val projectionRequestCode = 901
    private val micPermissionCode = 902

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScreenRecorderBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.backArrow.setOnClickListener { finish() }

        binding.historyList.layoutManager = LinearLayoutManager(this)

        binding.recordButton.setOnClickListener {
            if (ScreenRecordService.isRecording) {
                stopService(Intent(this, ScreenRecordService::class.java).setAction(ScreenRecordService.ACTION_STOP))
                refreshButtonState()
            } else {
                requestScreenCapture()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
        refreshButtonState()
        binding.historyList.adapter = RecordingAdapter(this, RecordingHistoryStore.getAll(this))
    }

    private fun applyTheme() {
        ThemeManager.applyScreenBackground(binding.recorderRoot)
        binding.screenTitle.setTextColor(ThemeManager.textPrimary(this))
        binding.micLabel.setTextColor(ThemeManager.textPrimary(this))
        binding.historyLabel.setTextColor(ThemeManager.textSecondary(this))
        binding.recordButton.setTextColor(ThemeManager.accentColor(this))
    }

    private fun refreshButtonState() {
        binding.recordButton.text = if (ScreenRecordService.isRecording) "Stop Recording" else "Start Recording"
        binding.micSwitch.isEnabled = !ScreenRecordService.isRecording
    }

    private fun requestScreenCapture() {
        if (binding.micSwitch.isChecked && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), micPermissionCode)
            return
        }
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), projectionRequestCode)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == projectionRequestCode && data != null) {
            val serviceIntent = Intent(this, ScreenRecordService::class.java).apply {
                action = ScreenRecordService.ACTION_START
                putExtra(ScreenRecordService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenRecordService.EXTRA_DATA, data)
                putExtra(ScreenRecordService.EXTRA_RECORD_MIC, binding.micSwitch.isChecked)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            refreshButtonState()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == micPermissionCode && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            requestScreenCapture()
        }
    }
}
