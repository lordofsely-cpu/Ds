package com.sely.launcher.privacy

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.sely.launcher.AppRepository
import com.sely.launcher.R
import com.sely.launcher.appmanagement.HiddenAppsStore
import com.sely.launcher.databinding.ActivityPrivacyCenterBinding
import com.sely.launcher.notifications.SelyNotificationListenerService
import com.sely.launcher.theme.ThemeManager

/**
 * Sely Privacy Center (spec section 9).
 *
 * See PrivacyLockStore and GuestModeStore's class docs for the exact,
 * stated scope of the PIN and Guest Space — both real launcher-level
 * features, neither a system security boundary (per spec §9's own
 * requirement not to claim OS-level isolation this can't provide).
 *
 * Not built here: "Layout lock" (home-screen icon rearranging isn't
 * implemented yet, so there's nothing to lock) and "Private search
 * history" (Sely Search has never stored history at all — nothing to
 * make private that isn't already absent).
 */
class PrivacyCenterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPrivacyCenterBinding
    private var allowlistQuery = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPrivacyCenterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.allowlistList.layoutManager = LinearLayoutManager(this)
        binding.allowlistSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                allowlistQuery = s?.toString().orEmpty()
                renderAllowlist()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        binding.guestSwitch.setOnCheckedChangeListener { _, checked ->
            GuestModeStore.setActive(this, checked)
        }
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
        renderPermissions()
        renderPin()
        binding.guestSwitch.setOnCheckedChangeListener(null)
        binding.guestSwitch.isChecked = GuestModeStore.isActive(this)
        binding.guestSwitch.setOnCheckedChangeListener { _, checked -> GuestModeStore.setActive(this, checked) }
        renderAllowlist()
        renderHidden()
    }

    private fun applyTheme() {
        ThemeManager.applyScreenBackground(binding.privacyRoot)
        val textPrimary = ThemeManager.textPrimary(this)
        val textSecondary = ThemeManager.textSecondary(this)
        binding.screenTitle.setTextColor(textPrimary)
        binding.permissionsHeader.setTextColor(textSecondary)
        binding.pinHeader.setTextColor(textSecondary)
        binding.pinNote.setTextColor(textSecondary)
        binding.guestHeader.setTextColor(textSecondary)
        binding.guestNote.setTextColor(textSecondary)
        binding.guestLabel.setTextColor(textPrimary)
        binding.hiddenHeader.setTextColor(textSecondary)
        binding.hiddenEmptyState.setTextColor(textSecondary)
        ThemeManager.applyGlass(binding.allowlistSearch, 22f)
        binding.allowlistSearch.setTextColor(textPrimary)
    }

    private fun renderPermissions() {
        binding.permissionsList.removeAllViews()
        val rows = listOf(
            Triple("Camera", granted(Manifest.permission.CAMERA)) { openAppSettings() },
            Triple("Microphone", granted(Manifest.permission.RECORD_AUDIO)) { openAppSettings() },
            Triple("Location (for Wi-Fi name)", granted(Manifest.permission.ACCESS_FINE_LOCATION)) { openAppSettings() },
            Triple("Contacts", granted(Manifest.permission.READ_CONTACTS)) { openAppSettings() },
            Triple("Notification access", SelyNotificationListenerService.isEnabled(this)) {
                startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
            },
            Triple("Default launcher", isDefaultLauncher()) {
                startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
            },
            Triple("Accessibility service", false) { }, // 🔴 Sely doesn't use one — always off, shown for transparency
            Triple("Draw over other apps", false) { } // 🔴 Sely doesn't use overlay permission
        )
        rows.forEach { (label, isGranted, onClick) -> addPermissionRow(label, isGranted, onClick) }
    }

    private fun granted(permission: String) = checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    private fun isDefaultLauncher(): Boolean {
        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val resolved = packageManager.resolveActivity(homeIntent, 0)
        return resolved?.activityInfo?.packageName == packageName
    }

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun addPermissionRow(label: String, isGranted: Boolean, onClick: () -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundResource(R.drawable.bg_glass_card)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            params.bottomMargin = dp(8)
            layoutParams = params
        }
        val text = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setTextColor(ThemeManager.textPrimary(this@PrivacyCenterActivity))
            text = label
        }
        val status = TextView(this).apply {
            setText(if (isGranted) "Granted" else "Not used")
            setTextColor(if (isGranted) ThemeManager.accentColor(this@PrivacyCenterActivity) else ThemeManager.textSecondary(this@PrivacyCenterActivity))
        }
        row.addView(text)
        row.addView(status)
        row.setOnClickListener { onClick() }
        binding.permissionsList.addView(row)
    }

    private fun renderPin() {
        val hasPin = PrivacyLockStore.hasPin(this)
        binding.pinRow.text = if (hasPin) "PIN is set — tap to change or remove" else "No PIN set — tap to create one"
        binding.pinRow.setTextColor(ThemeManager.accentColor(this))
        binding.pinRow.setOnClickListener {
            if (hasPin) showChangeOrRemovePinDialog() else promptSetPin()
        }
    }

    private fun promptSetPin() {
        val input = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        AlertDialog.Builder(this)
            .setTitle("Create a PIN")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val pin = input.text?.toString().orEmpty()
                if (pin.length >= 4) {
                    PrivacyLockStore.setPin(this, pin)
                    renderPin()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showChangeOrRemovePinDialog() {
        AlertDialog.Builder(this)
            .setTitle("Launcher PIN")
            .setItems(arrayOf("Change PIN", "Remove PIN")) { _, which ->
                if (which == 0) promptSetPin() else {
                    PrivacyLockStore.clearPin(this)
                    renderPin()
                }
            }
            .show()
    }

    private fun renderAllowlist() {
        val apps = AppRepository.loadLaunchableApps(this)
            .filter { it.label.contains(allowlistQuery, ignoreCase = true) }
        binding.allowlistList.adapter = GuestAllowlistAdapter(this, apps)
    }

    private fun renderHidden() {
        binding.hiddenList.removeAllViews()
        val hiddenPackages = HiddenAppsStore.getHidden(this)
        binding.hiddenEmptyState.visibility = if (hiddenPackages.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE

        val allApps = AppRepository.loadLaunchableApps(this).associateBy { it.packageName }
        hiddenPackages.forEach { pkg ->
            val app = allApps[pkg] ?: return@forEach
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundResource(R.drawable.bg_glass_card)
                setPadding(dp(14), dp(12), dp(14), dp(12))
                val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                params.bottomMargin = dp(8)
                layoutParams = params
            }
            val label = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                text = app.label
                setTextColor(ThemeManager.textPrimary(this@PrivacyCenterActivity))
            }
            val unhide = TextView(this).apply {
                text = "Unhide"
                setTextColor(ThemeManager.accentColor(this@PrivacyCenterActivity))
                setPadding(dp(8), dp(8), dp(8), dp(8))
                setOnClickListener {
                    HiddenAppsStore.setHidden(this@PrivacyCenterActivity, pkg, false)
                    renderHidden()
                }
            }
            row.addView(label)
            row.addView(unhide)
            binding.hiddenList.addView(row)
        }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
