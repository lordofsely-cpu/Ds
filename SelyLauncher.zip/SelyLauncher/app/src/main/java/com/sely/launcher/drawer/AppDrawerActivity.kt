package com.sely.launcher.drawer

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.sely.launcher.AppGridAdapter
import com.sely.launcher.AppInfo
import com.sely.launcher.AppRepository
import com.sely.launcher.R
import com.sely.launcher.databinding.ActivityAppDrawerBinding
import com.sely.launcher.theme.ThemeManager

/**
 * Sely App Drawer (spec section 2). Foundation build covers:
 *  - full alphabetical app list (🟢 PackageManager)
 *  - live search-by-name filtering (🟢 local, no extra permission)
 *
 * Not yet built here: categories, recents/frequently-used tracking,
 * hidden apps, custom drawer grid size, per-app icon overrides — each
 * needs its own small persistence layer (SharedPreferences/Room) and is
 * a good next increment on top of this file.
 */
class AppDrawerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAppDrawerBinding
    private var allApps: List<AppInfo> = emptyList()
    private var shownApps: List<AppInfo> = emptyList()
    private lateinit var gridManager: GridLayoutManager
    private val indexLetters: List<Char> = listOf('#') + ('A'..'Z').toList()
    private var firstLoadDone = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppDrawerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        if (com.sely.launcher.performance.PerformanceModeStore.animationsEnabled(this)) {
            overridePendingTransition(R.anim.slide_up_in, R.anim.no_anim)
        }

        gridManager = GridLayoutManager(this, 4)
        binding.drawerGrid.layoutManager = gridManager
        renderList(allApps)
        buildIndexStrip()

        // Load apps off the main thread so the drawer opens instantly.
        AppRepository.loadVisibleAppsAsync(this) { apps ->
            if (isFinishing || isDestroyed) return@loadVisibleAppsAsync
            allApps = apps
            renderList(currentFiltered())
            if (!firstLoadDone) {
                firstLoadDone = true
                if (com.sely.launcher.performance.PerformanceModeStore.animationsEnabled(this)) {
                    binding.drawerGrid.scheduleLayoutAnimation()
                }
            }
        }

        binding.drawerSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                renderList(currentFiltered())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun currentFiltered(): List<AppInfo> {
        val query = binding.drawerSearch.text?.toString()?.trim()?.lowercase().orEmpty()
        return if (query.isEmpty()) allApps else allApps.filter {
            it.label.lowercase().contains(query)
        }
    }

    private fun renderList(apps: List<AppInfo>) {
        shownApps = apps
        binding.drawerGrid.adapter = AppGridAdapter(this, apps)
    }

    /** Builds the A-Z strip and jumps the grid to the first app for a letter. */
    private fun buildIndexStrip() {
        binding.alphaIndex.removeAllViews()
        indexLetters.forEach { letter ->
            val tv = TextView(this)
            tv.text = letter.toString()
            tv.textSize = 10f
            tv.gravity = Gravity.CENTER
            tv.setTextColor(ThemeManager.accentColor(this))
            tv.layoutParams = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
            binding.alphaIndex.addView(tv)
        }
        binding.alphaIndex.setOnTouchListener { v, event ->
            val fraction = (event.y / v.height.toFloat()).coerceIn(0f, 0.999f)
            val letter = indexLetters[(fraction * indexLetters.size).toInt()]
            scrollToLetter(letter)
            if (event.actionMasked == MotionEvent.ACTION_UP) v.performClick()
            true
        }
    }

    private fun scrollToLetter(letter: Char) {
        val position = shownApps.indexOfFirst { app ->
            val first = app.label.trim().firstOrNull()?.uppercaseChar()
            if (letter == '#') first != null && !first.isLetter() else first == letter
        }
        if (position >= 0) gridManager.scrollToPositionWithOffset(position, 0)
    }

    override fun onResume() {
        super.onResume()
        ThemeManager.applyScreenBackground(binding.root)
        ThemeManager.applyGlass(binding.drawerSearch, 24f)
        binding.drawerSearch.setTextColor(ThemeManager.textPrimary(this))
        (0 until binding.alphaIndex.childCount).forEach { i ->
            (binding.alphaIndex.getChildAt(i) as? TextView)?.setTextColor(ThemeManager.accentColor(this))
        }
    }

    override fun finish() {
        super.finish()
        if (com.sely.launcher.performance.PerformanceModeStore.animationsEnabled(this)) {
            overridePendingTransition(R.anim.no_anim, R.anim.slide_down_out)
        }
    }
}
