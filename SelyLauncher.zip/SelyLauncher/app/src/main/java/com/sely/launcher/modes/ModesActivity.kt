package com.sely.launcher.modes

import android.app.AlertDialog
import android.os.Bundle
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.sely.launcher.R
import com.sely.launcher.databinding.ActivityModesBinding
import com.sely.launcher.theme.ThemeManager

/**
 * Sely Modes (spec section 23) — see ModeProfile's class doc for
 * exactly which settings each mode controls and why the list stops
 * there for now.
 */
class ModesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityModesBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityModesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.createCustom.setOnClickListener { promptSaveCustom() }
        buildRows()
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
    }

    private fun applyTheme() {
        binding.modesRoot.setBackgroundColor(ThemeManager.backgroundColor(this))
        binding.screenTitle.setTextColor(ThemeManager.textPrimary(this))
        binding.createCustom.setTextColor(ThemeManager.accentColor(this))
        binding.scopeNote.setTextColor(ThemeManager.textSecondary(this))
        binding.builtInHeader.setTextColor(ThemeManager.textSecondary(this))
        binding.customHeader.setTextColor(ThemeManager.textSecondary(this))
        buildRows()
    }

    private fun buildRows() {
        binding.builtInList.removeAllViews()
        binding.customList.removeAllViews()

        ModesStore.builtIns(this).forEach { profile -> addRow(binding.builtInList, profile) }

        val customs = ModesStore.customProfiles(this)
        binding.customHeader.visibility = if (customs.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE
        customs.forEach { profile -> addRow(binding.customList, profile) }
    }

    private fun addRow(container: LinearLayout, profile: ModeProfile) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundResource(R.drawable.bg_glass_card)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            params.bottomMargin = dp(10)
            layoutParams = params
        }

        val swatch = android.widget.ImageView(this).apply {
            val size = dp(14)
            layoutParams = LinearLayout.LayoutParams(size, size).apply { marginEnd = dp(12) }
            val drawable = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(profile.accentColor)
            }
            setImageDrawable(drawable)
        }

        val label = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            text = "${profile.name}\n" + buildString {
                append(if (profile.isDark) "Dark" else "Light")
                append(" · ${profile.performanceMode.label}")
                if (profile.dndOn) append(" · DND")
            }
            setTextColor(ThemeManager.textPrimary(this@ModesActivity))
            setLineSpacing(2f, 1f)
        }

        row.addView(swatch)
        row.addView(label)

        if (!profile.isBuiltIn) {
            val delete = TextView(this).apply {
                text = "✕"
                setTextColor(ThemeManager.textSecondary(this@ModesActivity))
                setPadding(dp(8), dp(8), dp(8), dp(8))
                setOnClickListener {
                    ModesStore.deleteCustom(this@ModesActivity, profile.name)
                    buildRows()
                }
            }
            row.addView(delete)
        }

        row.setOnClickListener {
            val neededPermission = ModeApplier.apply(this, profile)
            if (!neededPermission) {
                Toast.makeText(this, "${profile.name} mode applied", Toast.LENGTH_SHORT).show()
            }
            buildRows()
        }
        container.addView(row)
    }

    private fun promptSaveCustom() {
        val input = EditText(this)
        AlertDialog.Builder(this)
            .setTitle("Save current settings as a mode")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val name = input.text?.toString()?.trim().orEmpty()
                if (name.isNotBlank()) {
                    ModesStore.saveCustom(this, ModesStore.snapshotCurrent(this, name))
                    buildRows()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
