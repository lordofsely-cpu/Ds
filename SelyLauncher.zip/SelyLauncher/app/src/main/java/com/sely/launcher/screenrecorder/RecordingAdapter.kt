package com.sely.launcher.screenrecorder

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sely.launcher.R
import com.sely.launcher.theme.ThemeManager

class RecordingAdapter(
    private val context: Context,
    private val recordings: List<RecordingEntry>
) : RecyclerView.Adapter<RecordingAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val label: TextView = view.findViewById(R.id.recordingLabel)
        val open: TextView = view.findViewById(R.id.recordingOpen)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(context).inflate(R.layout.item_recording, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount() = recordings.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val entry = recordings[position]
        val dateText = DateFormat.format("MMM d, h:mm a", entry.timestampMillis)
        holder.label.text = "Recording · $dateText"
        holder.label.setTextColor(ThemeManager.textPrimary(context))
        holder.open.setTextColor(ThemeManager.accentColor(context))
        holder.open.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(Uri.parse(entry.uri), "video/mp4")
                flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
            }
            context.startActivity(intent)
        }
    }
}
