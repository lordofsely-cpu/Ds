package com.sely.launcher.sharehub

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable

/**
 * Sely Share Hub (spec section 18) — data layer.
 *
 * 🟢 Android's real mechanism for "what can handle sharing this" is
 * `PackageManager.queryIntentActivities()` against an `ACTION_SEND`
 * intent carrying the actual content — the same query the system
 * Sharesheet itself runs. This surfaces whatever's genuinely installed
 * (WhatsApp, Bluetooth, Nearby Share, Gmail, Messages, Drive, etc.) —
 * nothing here hardcodes that list, because doing so would either go
 * stale or show apps the user doesn't have.
 */
data class ShareTarget(val label: String, val icon: Drawable, val packageName: String, val activityName: String)

object ShareHubRepository {

    fun resolveTargets(context: Context, sendIntent: Intent): List<ShareTarget> {
        val pm = context.packageManager
        return pm.queryIntentActivities(sendIntent, 0).map { resolveInfo ->
            ShareTarget(
                label = resolveInfo.loadLabel(pm).toString(),
                icon = resolveInfo.loadIcon(pm),
                packageName = resolveInfo.activityInfo.packageName,
                activityName = resolveInfo.activityInfo.name
            )
        }
    }
}
