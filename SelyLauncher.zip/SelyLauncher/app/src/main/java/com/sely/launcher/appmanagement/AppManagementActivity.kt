package com.sely.launcher.appmanagement

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.sely.launcher.databinding.ActivityAppManagementBinding
import com.sely.launcher.theme.ThemeManager

/**
 * Sely App Management (spec section 35) — see AppManagementRepository
 * and HiddenAppsStore/FavoritesStore for what's real vs. launcher-level
 * only in each action here.
 */
class AppManagementActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAppManagementBinding
    private var allApps: List<ManagedAppInfo> = emptyList()
    private var query = ""
    private var unlocked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppManagementBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.backArrow.setOnClickListener { finish() }

        binding.appList.layoutManager = LinearLayoutManager(this)
        binding.appSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                query = s?.toString().orEmpty()
                render()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        // Same Launcher PIN gate as Settings — App Management is the
        // other real escape hatch out of Guest Space (it can unhide and
        // relaunch anything), so it's gated the same way. See
        // PrivacyLockStore/GuestModeStore for the honest scope of this.
        val guestActive = com.sely.launcher.privacy.GuestModeStore.isActive(this)
        val pinSet = com.sely.launcher.privacy.PrivacyLockStore.hasPin(this)
        if (guestActive && pinSet) {
            com.sely.launcher.privacy.PinPrompt.show(
                this,
                title = "Enter PIN to open App Management",
                onSuccess = { unlocked = true; refreshAndRender() },
                onCancel = { finish() }
            )
        } else {
            unlocked = true
        }
    }

    override fun onResume() {
        super.onResume()
        if (!unlocked) return
        refreshAndRender()
    }

    private fun refreshAndRender() {
        ThemeManager.applyScreenBackground(binding.appMgmtRoot)
        binding.screenTitle.setTextColor(ThemeManager.textPrimary(this))
        ThemeManager.applyGlass(binding.appSearch, 24f)
        binding.appSearch.setTextColor(ThemeManager.textPrimary(this))
        allApps = AppManagementRepository.loadAll(this)
        render()
    }

    private fun render() {
        val filtered = if (query.isBlank()) allApps else allApps.filter { it.app.label.contains(query, ignoreCase = true) }
        binding.appList.adapter = AppManagementAdapter(this, filtered) { render() }
    }
}
