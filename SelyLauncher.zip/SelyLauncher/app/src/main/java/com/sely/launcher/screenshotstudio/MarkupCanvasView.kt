package com.sely.launcher.screenshotstudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

enum class EditTool { NONE, DRAW, TEXT, BLUR, CROP }

data class TextItem(var x: Float, var y: Float, var text: String, val color: Int)

/**
 * Sely Screenshot Studio's editing surface (spec section 19).
 *
 * Design choice, stated plainly: freehand strokes and text are kept as
 * vector overlays (Path/TextItem lists) drawn fresh each frame — so
 * they stay editable/undoable — and are only flattened into the actual
 * bitmap at save time. Blur is different: it's baked directly into the
 * working bitmap's pixels the moment you drag over a region (via
 * BitmapBlur), because a real redaction has to actually remove the
 * underlying pixel data, not just sit a translucent layer on top of it.
 *
 * Known, honest limitation: rotating or cropping the working bitmap
 * clears in-progress draw/text overlays (their coordinates would
 * otherwise no longer line up with the transformed image). The UI
 * warns before doing either. Extending this to remap overlay
 * coordinates through the same Matrix is the natural next increment.
 */
class MarkupCanvasView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    var workingBitmap: Bitmap? = null
        set(value) {
            field = value
            paths.clear()
            textItems.clear()
            invalidate()
        }

    var tool: EditTool = EditTool.NONE
    var drawColor: Int = Color.RED
    var pendingTapListener: ((Float, Float) -> Unit)? = null

    private val paths = mutableListOf<Pair<Path, Paint>>()
    private var currentPath: Path? = null
    private val textItems = mutableListOf<TextItem>()
    private var draggingText: TextItem? = null
    private var cropRect: RectF? = null
    private var cropStart: PointF? = null

    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var scale = 1f
    private var offsetX = 0f
    private var offsetY = 0f

    constructor(context: Context) : this(context, null)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bmp = workingBitmap ?: return

        scale = minOf(width / bmp.width.toFloat(), height / bmp.height.toFloat())
        offsetX = (width - bmp.width * scale) / 2f
        offsetY = (height - bmp.height * scale) / 2f

        canvas.save()
        canvas.translate(offsetX, offsetY)
        canvas.scale(scale, scale)
        canvas.drawBitmap(bmp, 0f, 0f, bitmapPaint)
        paths.forEach { (path, paint) -> canvas.drawPath(path, paint) }
        textItems.forEach { item ->
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = item.color; textSize = 42f }
            canvas.drawText(item.text, item.x, item.y, paint)
        }
        cropRect?.let { rect ->
            val cropPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 3f / scale
            }
            canvas.drawRect(rect, cropPaint)
            val dimPaint = Paint().apply { color = Color.argb(120, 0, 0, 0) }
            canvas.drawRect(0f, 0f, bmp.width.toFloat(), rect.top, dimPaint)
            canvas.drawRect(0f, rect.bottom, bmp.width.toFloat(), bmp.height.toFloat(), dimPaint)
            canvas.drawRect(0f, rect.top, rect.left, rect.bottom, dimPaint)
            canvas.drawRect(rect.right, rect.top, bmp.width.toFloat(), rect.bottom, dimPaint)
        }
        canvas.restore()
    }

    private fun screenToBitmap(x: Float, y: Float): PointF =
        PointF((x - offsetX) / scale, (y - offsetY) / scale)

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val bmp = workingBitmap ?: return false
        val p = screenToBitmap(event.x, event.y)

        when (tool) {
            EditTool.DRAW -> {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        currentPath = Path().apply { moveTo(p.x, p.y) }
                        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = drawColor; style = Paint.Style.STROKE; strokeWidth = 8f; strokeCap = Paint.Cap.ROUND
                        }
                        paths.add(currentPath!! to paint)
                    }
                    MotionEvent.ACTION_MOVE -> currentPath?.lineTo(p.x, p.y)
                }
                invalidate()
            }
            EditTool.BLUR -> {
                if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
                    BitmapBlur.blurRegion(bmp, p.x.toInt(), p.y.toInt(), brushRadius = 40)
                    invalidate()
                }
            }
            EditTool.TEXT -> {
                if (event.action == MotionEvent.ACTION_DOWN) {
                    val hit = textItems.lastOrNull { kotlin.math.abs(it.x - p.x) < 60 && kotlin.math.abs(it.y - p.y) < 60 }
                    if (hit != null) {
                        draggingText = hit
                    } else {
                        pendingTapListener?.invoke(p.x, p.y)
                    }
                } else if (event.action == MotionEvent.ACTION_MOVE && draggingText != null) {
                    draggingText!!.x = p.x
                    draggingText!!.y = p.y
                    invalidate()
                } else if (event.action == MotionEvent.ACTION_UP) {
                    draggingText = null
                }
            }
            EditTool.CROP -> {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        cropStart = p
                        cropRect = RectF(p.x, p.y, p.x, p.y)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        cropStart?.let { start ->
                            cropRect = RectF(
                                minOf(start.x, p.x), minOf(start.y, p.y),
                                maxOf(start.x, p.x), maxOf(start.y, p.y)
                            )
                        }
                    }
                }
                invalidate()
            }
            else -> return false
        }
        return true
    }

    fun hasCropSelection() = cropRect != null

    fun applyPendingCrop() {
        cropRect?.let { cropTo(it) }
        cropRect = null
    }

    fun addText(x: Float, y: Float, text: String) {
        textItems.add(TextItem(x, y, text, drawColor))
        invalidate()
    }

    fun undoLast() {
        if (paths.isNotEmpty()) paths.removeAt(paths.size - 1)
        else if (textItems.isNotEmpty()) textItems.removeAt(textItems.size - 1)
        invalidate()
    }

    fun rotate90() {
        val bmp = workingBitmap ?: return
        val matrix = Matrix().apply { postRotate(90f) }
        workingBitmap = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, matrix, true)
    }

    fun cropTo(rectInBitmapSpace: RectF) {
        val bmp = workingBitmap ?: return
        val left = rectInBitmapSpace.left.toInt().coerceIn(0, bmp.width - 1)
        val top = rectInBitmapSpace.top.toInt().coerceIn(0, bmp.height - 1)
        val w = (rectInBitmapSpace.width().toInt()).coerceAtMost(bmp.width - left)
        val h = (rectInBitmapSpace.height().toInt()).coerceAtMost(bmp.height - top)
        if (w <= 0 || h <= 0) return
        workingBitmap = Bitmap.createBitmap(bmp, left, top, w, h)
    }

    /** Flattens overlays onto a copy of the working bitmap for saving. */
    fun renderFlattenedBitmap(): Bitmap? {
        val bmp = workingBitmap ?: return null
        val output = bmp.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(output)
        paths.forEach { (path, paint) -> canvas.drawPath(path, paint) }
        textItems.forEach { item ->
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = item.color; textSize = 42f }
            canvas.drawText(item.text, item.x, item.y, paint)
        }
        return output
    }
}
