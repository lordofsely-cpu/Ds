package com.sely.launcher.soundhaptics

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Manifest-declared receiver for ACTION_POWER_CONNECTED — see
 * SoundHapticsManager's class doc for why this broadcast specifically
 * (unlike most implicit broadcasts since Android 8) still works this
 * way without a persistent foreground service.
 */
class ChargingSoundReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_POWER_CONNECTED) {
            SoundHapticsManager.onChargingStarted(context)
        }
    }
}
