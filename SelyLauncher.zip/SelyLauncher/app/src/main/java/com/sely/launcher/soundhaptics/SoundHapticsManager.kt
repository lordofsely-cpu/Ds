package com.sely.launcher.soundhaptics

import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.HapticFeedbackConstants
import android.view.View

/**
 * Sely Sound & Haptics (spec section 41).
 *
 * 🟢 App-open/folder sounds use `AudioManager.playSoundEffect()` with
 * the platform's built-in effect tones (`FX_KEY_CLICK`, etc.) — real
 * system sounds, no bundled audio asset needed, and they respect the
 * user's system "Touch sounds" master setting automatically (Android
 * silently no-ops the call if that's off).
 *
 * 🟢 Gesture/touch haptics use `Vibrator`/`VibrationEffect` directly
 * (for gesture callbacks with no View handy) or `View.performHapticFeedback`
 * (for direct taps) — both real, standard APIs.
 *
 * 🟢 Charging sound is driven by the real `ACTION_POWER_CONNECTED`
 * broadcast (see ChargingSoundReceiver) — one of the few implicit
 * broadcasts Android still allows a manifest-declared receiver for.
 *
 * 🔴 Deliberately NOT built: a "lock sound". Screen on/off broadcasts
 * (`ACTION_SCREEN_OFF`) are explicitly excluded from manifest-declared
 * receivers — the only way to catch them is a permanently-running
 * foreground service, which is a real but heavy, battery-costing
 * trade-off this project isn't making quietly. Noted in the Settings UI
 * rather than faked.
 *
 * Every trigger below checks its own toggle first — this file both
 * implements the effects and enforces the on/off switches, so a screen
 * only ever needs to read/write the prefs, never gate playback itself.
 */
object SoundHapticsManager {

    private const val PREFS = "sely_sound_haptics"
    private const val KEY_APP_SOUNDS = "app_sounds"
    private const val KEY_TOUCH_HAPTICS = "touch_haptics"
    private const val KEY_CHARGING_SOUND = "charging_sound"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun appSoundsEnabled(context: Context) = prefs(context).getBoolean(KEY_APP_SOUNDS, true)
    fun touchHapticsEnabled(context: Context) = prefs(context).getBoolean(KEY_TOUCH_HAPTICS, true)
    fun chargingSoundEnabled(context: Context) = prefs(context).getBoolean(KEY_CHARGING_SOUND, false)

    fun setAppSoundsEnabled(context: Context, enabled: Boolean) =
        prefs(context).edit().putBoolean(KEY_APP_SOUNDS, enabled).apply()
    fun setTouchHapticsEnabled(context: Context, enabled: Boolean) =
        prefs(context).edit().putBoolean(KEY_TOUCH_HAPTICS, enabled).apply()
    fun setChargingSoundEnabled(context: Context, enabled: Boolean) =
        prefs(context).edit().putBoolean(KEY_CHARGING_SOUND, enabled).apply()

    /** Call when an app is launched through Sely. */
    fun onAppOpen(context: Context, sourceView: View?) {
        if (appSoundsEnabled(context)) {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.playSoundEffect(AudioManager.FX_KEY_CLICK)
        }
        if (touchHapticsEnabled(context) && sourceView != null) {
            sourceView.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }
    }

    /** Call when a folder opens/closes. */
    fun onFolderToggle(context: Context, sourceView: View?) {
        if (appSoundsEnabled(context)) {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.playSoundEffect(AudioManager.FX_FOCUS_NAVIGATION_UP)
        }
        if (touchHapticsEnabled(context) && sourceView != null) {
            sourceView.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        }
    }

    /** Call from gesture callbacks (no View available at that point). */
    fun onGesture(context: Context) {
        if (!touchHapticsEnabled(context)) return
        val vibrator: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(20, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(20)
        }
    }

    /** Called by ChargingSoundReceiver on ACTION_POWER_CONNECTED. */
    fun onChargingStarted(context: Context) {
        if (!chargingSoundEnabled(context)) return
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.playSoundEffect(AudioManager.FX_KEYPRESS_RETURN)
    }
}
